"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FolderOpen, Plus, Users, CheckCircle, AlertTriangle, Target } from "lucide-react"

export default function ProjectManagementModule() {
  const projects = [
    {
      id: 1,
      name: "تطوير موقع الشركة الجديد",
      client: "شركة الأمل للتجارة",
      progress: 75,
      status: "قيد التنفيذ",
      startDate: "2024-01-01",
      endDate: "2024-03-01",
      budget: "150,000 ر.س",
      team: ["أحمد محمد", "فاطمة علي", "محمد سالم"],
      tasksCompleted: 15,
      totalTasks: 20,
    },
    {
      id: 2,
      name: "نظام إدارة المخزون",
      client: "مؤسسة النور",
      progress: 45,
      status: "قيد التنفيذ",
      startDate: "2024-01-15",
      endDate: "2024-04-15",
      budget: "200,000 ر.س",
      team: ["سارة أحمد", "علي محمد"],
      tasksCompleted: 9,
      totalTasks: 20,
    },
    {
      id: 3,
      name: "تطبيق الجوال للمبيعات",
      client: "شركة التقنية المتقدمة",
      progress: 90,
      status: "قريب الانتهاء",
      startDate: "2023-11-01",
      endDate: "2024-02-01",
      budget: "300,000 ر.س",
      team: ["محمد أحمد", "نورا سالم", "خالد علي"],
      tasksCompleted: 18,
      totalTasks: 20,
    },
  ]

  const tasks = [
    {
      id: 1,
      title: "تصميم واجهة المستخدم الرئيسية",
      project: "تطوير موقع الشركة الجديد",
      assignee: "أحمد محمد",
      priority: "عالية",
      status: "مكتمل",
      dueDate: "2024-01-20",
      progress: 100,
    },
    {
      id: 2,
      title: "تطوير نظام المصادقة",
      project: "نظام إدارة المخزون",
      assignee: "فاطمة علي",
      priority: "متوسطة",
      status: "قيد التنفيذ",
      dueDate: "2024-01-25",
      progress: 60,
    },
    {
      id: 3,
      title: "اختبار التطبيق على الأجهزة",
      project: "تطبيق الجوال للمبيعات",
      assignee: "محمد سالم",
      priority: "عالية",
      status: "معلق",
      dueDate: "2024-01-18",
      progress: 0,
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "مكتمل":
        return "bg-green-100 text-green-800"
      case "قيد التنفيذ":
        return "bg-blue-100 text-blue-800"
      case "قريب الانتهاء":
        return "bg-purple-100 text-purple-800"
      case "معلق":
        return "bg-yellow-100 text-yellow-800"
      case "متأخر":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "عالية":
        return "bg-red-100 text-red-800"
      case "متوسطة":
        return "bg-yellow-100 text-yellow-800"
      case "منخفضة":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">إدارة المشاريع</h1>
          <p className="text-gray-600 mt-1">متابعة المشاريع والمهام والفرق</p>
        </div>
        <Button className="gap-2">
          <Plus className="w-4 h-4" />
          مشروع جديد
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">المشاريع النشطة</p>
                <p className="text-2xl font-bold text-gray-900">12</p>
              </div>
              <FolderOpen className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">المهام المكتملة</p>
                <p className="text-2xl font-bold text-gray-900">156</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">المهام المتأخرة</p>
                <p className="text-2xl font-bold text-gray-900">8</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">معدل الإنجاز</p>
                <p className="text-2xl font-bold text-gray-900">87%</p>
              </div>
              <Target className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="projects" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="projects">المشاريع</TabsTrigger>
          <TabsTrigger value="tasks">المهام</TabsTrigger>
        </TabsList>

        <TabsContent value="projects" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {projects.map((project) => (
              <Card key={project.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{project.name}</CardTitle>
                      <CardDescription>{project.client}</CardDescription>
                    </div>
                    <Badge className={getStatusColor(project.status)}>{project.status}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>التقدم</span>
                      <span>{project.progress}%</span>
                    </div>
                    <Progress value={project.progress} className="h-2" />
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">تاريخ البداية</p>
                      <p className="font-medium">{project.startDate}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">تاريخ الانتهاء</p>
                      <p className="font-medium">{project.endDate}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">الميزانية</p>
                      <p className="font-medium">{project.budget}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">المهام</p>
                      <p className="font-medium">
                        {project.tasksCompleted}/{project.totalTasks}
                      </p>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-gray-600 mb-2">فريق العمل</p>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-gray-400" />
                      <span className="text-sm">{project.team.join(", ")}</span>
                    </div>
                  </div>

                  <Button variant="outline" className="w-full bg-transparent">
                    عرض تفاصيل المشروع
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="tasks" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>قائمة المهام</CardTitle>
              <CardDescription>جميع المهام المسندة للفريق</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {tasks.map((task) => (
                  <div key={task.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <CheckCircle className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{task.title}</h3>
                        <p className="text-sm text-gray-600">{task.project}</p>
                        <p className="text-xs text-gray-500 mt-1">مسند إلى: {task.assignee}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <p className="text-sm text-gray-600">موعد التسليم</p>
                        <p className="text-sm font-medium">{task.dueDate}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600">التقدم</p>
                        <p className="font-bold">{task.progress}%</p>
                      </div>
                      <Badge className={getPriorityColor(task.priority)}>{task.priority}</Badge>
                      <Badge className={getStatusColor(task.status)}>{task.status}</Badge>
                      <Button variant="outline" size="sm">
                        تعديل
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
