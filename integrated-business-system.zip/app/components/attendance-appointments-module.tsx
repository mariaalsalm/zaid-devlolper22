"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Clock, Calendar, Users, CheckCircle, XCircle, AlertCircle, MapPin } from "lucide-react"

export default function AttendanceAppointmentsModule() {
  const attendanceRecords = [
    {
      id: 1,
      employee: "أحمد محمد",
      date: "2024-01-16",
      checkIn: "08:00",
      checkOut: "17:00",
      workingHours: "9:00",
      status: "حاضر",
      overtime: "1:00",
    },
    {
      id: 2,
      employee: "فاطمة علي",
      date: "2024-01-16",
      checkIn: "08:15",
      checkOut: "17:30",
      workingHours: "9:15",
      status: "متأخر",
      overtime: "1:30",
    },
    {
      id: 3,
      employee: "محمد سالم",
      date: "2024-01-16",
      checkIn: "-",
      checkOut: "-",
      workingHours: "0:00",
      status: "غائب",
      overtime: "0:00",
    },
  ]

  const appointments = [
    {
      id: 1,
      title: "اجتماع مع العميل الجديد",
      client: "شركة الأمل للتجارة",
      date: "2024-01-17",
      time: "10:00 - 11:30",
      location: "قاعة الاجتماعات الرئيسية",
      attendees: ["أحمد محمد", "فاطمة علي"],
      status: "مؤكد",
      type: "اجتماع عمل",
    },
    {
      id: 2,
      title: "عرض تقديمي للمشروع الجديد",
      client: "مؤسسة النور",
      date: "2024-01-18",
      time: "14:00 - 15:30",
      location: "قاعة العروض",
      attendees: ["محمد سالم", "سارة أحمد"],
      status: "معلق",
      type: "عرض تقديمي",
    },
    {
      id: 3,
      title: "مراجعة التقارير الشهرية",
      client: "داخلي",
      date: "2024-01-19",
      time: "09:00 - 10:00",
      location: "مكتب المدير",
      attendees: ["جميع المديرين"],
      status: "مؤكد",
      type: "اجتماع داخلي",
    },
  ]

  const getAttendanceStatusColor = (status: string) => {
    switch (status) {
      case "حاضر":
        return "bg-green-100 text-green-800"
      case "متأخر":
        return "bg-yellow-100 text-yellow-800"
      case "غائب":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getAppointmentStatusColor = (status: string) => {
    switch (status) {
      case "مؤكد":
        return "bg-green-100 text-green-800"
      case "معلق":
        return "bg-yellow-100 text-yellow-800"
      case "ملغي":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getAttendanceIcon = (status: string) => {
    switch (status) {
      case "حاضر":
        return <CheckCircle className="w-6 h-6 text-green-600" />
      case "متأخر":
        return <AlertCircle className="w-6 h-6 text-yellow-600" />
      case "غائب":
        return <XCircle className="w-6 h-6 text-red-600" />
      default:
        return <Clock className="w-6 h-6 text-gray-600" />
    }
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">الحضور والمواعيد</h1>
          <p className="text-gray-600 mt-1">إدارة حضور الموظفين والمواعيد</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2 bg-transparent">
            <Clock className="w-4 h-4" />
            تسجيل الحضور
          </Button>
          <Button className="gap-2">
            <Calendar className="w-4 h-4" />
            موعد جديد
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">الحضور اليوم</p>
                <p className="text-2xl font-bold text-green-600">142/156</p>
                <p className="text-sm text-gray-500 mt-1">91% معدل الحضور</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">المتأخرون</p>
                <p className="text-2xl font-bold text-yellow-600">8</p>
                <p className="text-sm text-gray-500 mt-1">5% من الموظفين</p>
              </div>
              <AlertCircle className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">الغائبون</p>
                <p className="text-2xl font-bold text-red-600">6</p>
                <p className="text-sm text-gray-500 mt-1">4% من الموظفين</p>
              </div>
              <XCircle className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">المواعيد اليوم</p>
                <p className="text-2xl font-bold text-blue-600">12</p>
                <p className="text-sm text-gray-500 mt-1">3 مواعيد معلقة</p>
              </div>
              <Calendar className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="attendance" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="attendance">سجل الحضور</TabsTrigger>
          <TabsTrigger value="appointments">المواعيد</TabsTrigger>
        </TabsList>

        <TabsContent value="attendance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>سجل الحضور اليومي</CardTitle>
              <CardDescription>حضور الموظفين لتاريخ اليوم</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {attendanceRecords.map((record) => (
                  <div key={record.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
                        {getAttendanceIcon(record.status)}
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{record.employee}</h3>
                        <p className="text-sm text-gray-600">{record.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-600">دخول</p>
                        <p className="font-medium">{record.checkIn}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600">خروج</p>
                        <p className="font-medium">{record.checkOut}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600">ساعات العمل</p>
                        <p className="font-medium">{record.workingHours}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600">إضافي</p>
                        <p className="font-medium text-blue-600">{record.overtime}</p>
                      </div>
                      <Badge className={getAttendanceStatusColor(record.status)}>{record.status}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="appointments" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>المواعيد القادمة</CardTitle>
              <CardDescription>جميع المواعيد المجدولة</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {appointments.map((appointment) => (
                  <div key={appointment.id} className="flex items-start justify-between p-4 border rounded-lg">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <Calendar className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{appointment.title}</h3>
                        <p className="text-sm text-gray-600 mt-1">{appointment.client}</p>
                        <div className="flex items-center gap-4 text-sm text-gray-500 mt-2">
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {appointment.date} • {appointment.time}
                          </span>
                          <span className="flex items-center gap-1">
                            <MapPin className="w-4 h-4" />
                            {appointment.location}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 mt-2">
                          <Users className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-600">
                            {Array.isArray(appointment.attendees)
                              ? appointment.attendees.join(", ")
                              : appointment.attendees}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-left">
                        <Badge variant="outline" className="mb-2">
                          {appointment.type}
                        </Badge>
                        <Badge className={getAppointmentStatusColor(appointment.status)}>{appointment.status}</Badge>
                      </div>
                      <Button variant="outline" size="sm">
                        عرض التفاصيل
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
