"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, UserPlus, Phone, Mail, Calendar, DollarSign, TrendingUp, Search, Filter } from "lucide-react"

export default function CRMModule() {
  const [searchTerm, setSearchTerm] = useState("")

  const customers = [
    {
      id: 1,
      name: "شركة الأمل للتجارة",
      email: "info@alamal.com",
      phone: "+966501234567",
      status: "نشط",
      value: "150,000 ر.س",
      lastContact: "2024-01-15",
      type: "شركة",
    },
    {
      id: 2,
      name: "محمد أحمد السالم",
      email: "mohammed@email.com",
      phone: "+966507654321",
      status: "محتمل",
      value: "75,000 ر.س",
      lastContact: "2024-01-10",
      type: "فرد",
    },
    {
      id: 3,
      name: "مؤسسة النور للخدمات",
      email: "contact@alnoor.com",
      phone: "+966551234567",
      status: "نشط",
      value: "200,000 ر.س",
      lastContact: "2024-01-12",
      type: "مؤسسة",
    },
  ]

  const leads = [
    {
      id: 1,
      name: "سارة محمد",
      source: "الموقع الإلكتروني",
      status: "جديد",
      score: 85,
      value: "50,000 ر.س",
      date: "2024-01-16",
    },
    {
      id: 2,
      name: "شركة التقنية المتقدمة",
      source: "معرض تجاري",
      status: "متابعة",
      score: 92,
      value: "300,000 ر.س",
      date: "2024-01-14",
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "نشط":
        return "bg-green-100 text-green-800"
      case "محتمل":
        return "bg-yellow-100 text-yellow-800"
      case "جديد":
        return "bg-blue-100 text-blue-800"
      case "متابعة":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">إدارة علاقات العملاء</h1>
          <p className="text-gray-600 mt-1">إدارة العملاء والعملاء المحتملين</p>
        </div>
        <Button className="gap-2">
          <UserPlus className="w-4 h-4" />
          إضافة عميل جديد
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">إجمالي العملاء</p>
                <p className="text-2xl font-bold text-gray-900">1,234</p>
              </div>
              <Users className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">العملاء النشطون</p>
                <p className="text-2xl font-bold text-gray-900">856</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">العملاء المحتملون</p>
                <p className="text-2xl font-bold text-gray-900">234</p>
              </div>
              <Calendar className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">قيمة العملاء</p>
                <p className="text-2xl font-bold text-gray-900">2.5M ر.س</p>
              </div>
              <DollarSign className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="customers" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="customers">العملاء</TabsTrigger>
          <TabsTrigger value="leads">العملاء المحتملون</TabsTrigger>
        </TabsList>

        <TabsContent value="customers" className="space-y-6">
          {/* Search and Filter */}
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="البحث عن العملاء..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
            </div>
            <Button variant="outline" className="gap-2 bg-transparent">
              <Filter className="w-4 h-4" />
              تصفية
            </Button>
          </div>

          {/* Customers List */}
          <Card>
            <CardHeader>
              <CardTitle>قائمة العملاء</CardTitle>
              <CardDescription>جميع العملاء المسجلين في النظام</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {customers.map((customer) => (
                  <div key={customer.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <Users className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{customer.name}</h3>
                        <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                          <span className="flex items-center gap-1">
                            <Mail className="w-4 h-4" />
                            {customer.email}
                          </span>
                          <span className="flex items-center gap-1">
                            <Phone className="w-4 h-4" />
                            {customer.phone}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-left">
                        <p className="font-semibold text-gray-900">{customer.value}</p>
                        <p className="text-sm text-gray-600">آخر تواصل: {customer.lastContact}</p>
                      </div>
                      <Badge className={getStatusColor(customer.status)}>{customer.status}</Badge>
                      <Button variant="outline" size="sm">
                        عرض التفاصيل
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leads" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>العملاء المحتملون</CardTitle>
              <CardDescription>العملاء المحتملون الجدد والمتابعة</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {leads.map((lead) => (
                  <div key={lead.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                        <UserPlus className="w-6 h-6 text-orange-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{lead.name}</h3>
                        <p className="text-sm text-gray-600">المصدر: {lead.source}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <p className="text-sm text-gray-600">نقاط الجودة</p>
                        <p className="font-bold text-lg">{lead.score}</p>
                      </div>
                      <div className="text-left">
                        <p className="font-semibold text-gray-900">{lead.value}</p>
                        <p className="text-sm text-gray-600">{lead.date}</p>
                      </div>
                      <Badge className={getStatusColor(lead.status)}>{lead.status}</Badge>
                      <Button variant="outline" size="sm">
                        متابعة
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
