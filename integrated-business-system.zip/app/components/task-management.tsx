"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { CheckSquare, Plus, Calendar, Clock, User, Flag, Filter, MoreHorizontal } from "lucide-react"

export default function TaskManagement() {
  const [tasks, setTasks] = useState([
    {
      id: 1,
      title: "تصميم واجهة المستخدم الجديدة",
      description: "إنشاء تصميم حديث ومتجاوب لصفحة الرئيسية",
      assignee: "أحمد محمد",
      project: "تطوير الموقع",
      priority: "عالية",
      status: "قيد التنفيذ",
      progress: 75,
      dueDate: "2024-01-25",
      createdDate: "2024-01-10",
      tags: ["تصميم", "واجهة المستخدم"],
    },
    {
      id: 2,
      title: "مراجعة التقارير المالية",
      description: "مراجعة وتدقيق التقارير المالية للربع الأول",
      assignee: "فاطمة علي",
      project: "المحاسبة",
      priority: "متوسطة",
      status: "مكتمل",
      progress: 100,
      dueDate: "2024-01-20",
      createdDate: "2024-01-05",
      tags: ["مالية", "تقارير"],
    },
    {
      id: 3,
      title: "تطوير نظام المصادقة",
      description: "إضافة نظام مصادقة ثنائية للأمان",
      assignee: "محمد سالم",
      project: "الأمان",
      priority: "عالية",
      status: "معلق",
      progress: 30,
      dueDate: "2024-02-01",
      createdDate: "2024-01-12",
      tags: ["أمان", "برمجة"],
    },
    {
      id: 4,
      title: "تحديث قاعدة البيانات",
      description: "ترقية قاعدة البيانات وتحسين الأداء",
      assignee: "سارة أحمد",
      project: "البنية التحتية",
      priority: "منخفضة",
      status: "جديد",
      progress: 0,
      dueDate: "2024-02-15",
      createdDate: "2024-01-15",
      tags: ["قاعدة بيانات", "أداء"],
    },
  ])

  const projects = [
    { name: "تطوير الموقع", tasks: 8, completed: 6 },
    { name: "المحاسبة", tasks: 5, completed: 4 },
    { name: "الأمان", tasks: 3, completed: 1 },
    { name: "البنية التحتية", tasks: 4, completed: 2 },
  ]

  const teamMembers = [
    { name: "أحمد محمد", tasks: 5, completed: 3, avatar: "/placeholder.svg?height=32&width=32" },
    { name: "فاطمة علي", tasks: 4, completed: 4, avatar: "/placeholder.svg?height=32&width=32" },
    { name: "محمد سالم", tasks: 3, completed: 1, avatar: "/placeholder.svg?height=32&width=32" },
    { name: "سارة أحمد", tasks: 2, completed: 1, avatar: "/placeholder.svg?height=32&width=32" },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "مكتمل":
        return "bg-green-100 text-green-800"
      case "قيد التنفيذ":
        return "bg-blue-100 text-blue-800"
      case "معلق":
        return "bg-yellow-100 text-yellow-800"
      case "جديد":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "عالية":
        return "bg-red-100 text-red-800"
      case "متوسطة":
        return "bg-yellow-100 text-yellow-800"
      case "منخفضة":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityIcon = (priority: string) => {
    const baseClass = "w-4 h-4"
    switch (priority) {
      case "عالية":
        return <Flag className={`${baseClass} text-red-600`} />
      case "متوسطة":
        return <Flag className={`${baseClass} text-yellow-600`} />
      case "منخفضة":
        return <Flag className={`${baseClass} text-green-600`} />
      default:
        return <Flag className={`${baseClass} text-gray-600`} />
    }
  }

  const updateTaskStatus = (taskId: number, newStatus: string) => {
    setTasks(tasks.map((task) => (task.id === taskId ? { ...task, status: newStatus } : task)))
  }

  const completedTasks = tasks.filter((task) => task.status === "مكتمل").length
  const inProgressTasks = tasks.filter((task) => task.status === "قيد التنفيذ").length
  const pendingTasks = tasks.filter((task) => task.status === "معلق").length
  const newTasks = tasks.filter((task) => task.status === "جديد").length

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">إدارة المهام</h1>
          <p className="text-gray-600 mt-1">تنظيم ومتابعة المهام والمشاريع</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2 bg-transparent">
            <Filter className="w-4 h-4" />
            تصفية
          </Button>
          <Button className="gap-2">
            <Plus className="w-4 h-4" />
            مهمة جديدة
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">المهام المكتملة</p>
                <p className="text-2xl font-bold text-green-600">{completedTasks}</p>
              </div>
              <CheckSquare className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">قيد التنفيذ</p>
                <p className="text-2xl font-bold text-blue-600">{inProgressTasks}</p>
              </div>
              <Clock className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">معلقة</p>
                <p className="text-2xl font-bold text-yellow-600">{pendingTasks}</p>
              </div>
              <Calendar className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">جديدة</p>
                <p className="text-2xl font-bold text-gray-600">{newTasks}</p>
              </div>
              <Plus className="w-8 h-8 text-gray-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="tasks" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="tasks">المهام</TabsTrigger>
          <TabsTrigger value="projects">المشاريع</TabsTrigger>
          <TabsTrigger value="team">الفريق</TabsTrigger>
        </TabsList>

        <TabsContent value="tasks" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>قائمة المهام</CardTitle>
              <CardDescription>جميع المهام المسندة للفريق</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {tasks.map((task) => (
                  <div key={task.id} className="border rounded-lg p-4 space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold text-gray-900">{task.title}</h3>
                          {getPriorityIcon(task.priority)}
                          <Badge className={getPriorityColor(task.priority)} variant="outline">
                            {task.priority}
                          </Badge>
                          <Badge className={getStatusColor(task.status)}>{task.status}</Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-3">{task.description}</p>

                        <div className="flex items-center gap-6 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <User className="w-4 h-4" />
                            {task.assignee}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {task.dueDate}
                          </span>
                          <span>{task.project}</span>
                        </div>

                        <div className="flex items-center gap-2 mt-3">
                          {task.tags.map((tag, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-center min-w-[80px]">
                          <p className="text-sm text-gray-600 mb-1">التقدم</p>
                          <p className="font-bold text-lg">{task.progress}%</p>
                          <Progress value={task.progress} className="h-2 w-16" />
                        </div>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="projects" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {projects.map((project, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckSquare className="w-5 h-5" />
                    {project.name}
                  </CardTitle>
                  <CardDescription>
                    {project.completed} من {project.tasks} مهام مكتملة
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>التقدم الإجمالي</span>
                        <span>{Math.round((project.completed / project.tasks) * 100)}%</span>
                      </div>
                      <Progress value={(project.completed / project.tasks) * 100} className="h-2" />
                    </div>

                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-600">المهام المتبقية</span>
                      <span className="font-medium">{project.tasks - project.completed}</span>
                    </div>

                    <Button variant="outline" className="w-full bg-transparent">
                      عرض تفاصيل المشروع
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="team" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>أعضاء الفريق</CardTitle>
              <CardDescription>أداء أعضاء الفريق في المهام</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {teamMembers.map((member, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <Avatar>
                        <AvatarImage src={member.avatar || "/placeholder.svg"} alt={member.name} />
                        <AvatarFallback>{member.name.split(" ")[0][0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold text-gray-900">{member.name}</h3>
                        <p className="text-sm text-gray-600">
                          {member.completed} من {member.tasks} مهام مكتملة
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <p className="text-sm text-gray-600">معدل الإنجاز</p>
                        <p className="font-bold text-lg">{Math.round((member.completed / member.tasks) * 100)}%</p>
                      </div>
                      <div className="w-20">
                        <Progress value={(member.completed / member.tasks) * 100} className="h-2" />
                      </div>
                      <Button variant="outline" size="sm">
                        عرض المهام
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
