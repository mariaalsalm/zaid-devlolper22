"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Settings, Database, Shield, Bell, Globe, Users, Mail, Smartphone, Cloud, Server, Zap } from "lucide-react"

export default function AdvancedSettings() {
  const [settings, setSettings] = useState({
    // System Settings
    autoBackup: true,
    backupFrequency: "daily",
    maintenanceMode: false,
    debugMode: false,

    // Security Settings
    twoFactorAuth: true,
    sessionTimeout: 30,
    passwordPolicy: "strong",
    loginAttempts: 3,

    // Notification Settings
    emailNotifications: true,
    pushNotifications: true,
    smsNotifications: false,
    notificationSound: true,

    // Integration Settings
    apiAccess: true,
    webhooks: false,
    thirdPartyIntegrations: true,
    dataSync: true,
  })

  const systemInfo = {
    version: "2.1.0",
    lastUpdate: "2024-01-15",
    uptime: "15 أيام، 6 ساعات",
    storage: "2.3 GB / 10 GB",
    users: 156,
    activeUsers: 89,
  }

  const integrations = [
    { name: "Google Workspace", status: "متصل", icon: Mail },
    { name: "Microsoft 365", status: "غير متصل", icon: Cloud },
    { name: "Slack", status: "متصل", icon: Smartphone },
    { name: "Zoom", status: "متصل", icon: Globe },
  ]

  const getStatusColor = (status: string) => {
    return status === "متصل" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">الإعدادات المتقدمة</h1>
          <p className="text-gray-600 mt-1">إدارة إعدادات النظام والأمان</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2 bg-transparent">
            <Database className="w-4 h-4" />
            نسخ احتياطي
          </Button>
          <Button className="gap-2">
            <Settings className="w-4 h-4" />
            حفظ الإعدادات
          </Button>
        </div>
      </div>

      {/* System Info Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">إصدار النظام</p>
                <p className="text-2xl font-bold text-gray-900">{systemInfo.version}</p>
                <p className="text-sm text-gray-500">آخر تحديث: {systemInfo.lastUpdate}</p>
              </div>
              <Server className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">وقت التشغيل</p>
                <p className="text-2xl font-bold text-gray-900">{systemInfo.uptime}</p>
                <p className="text-sm text-green-600">النظام يعمل بشكل طبيعي</p>
              </div>
              <Zap className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">المستخدمون النشطون</p>
                <p className="text-2xl font-bold text-gray-900">
                  {systemInfo.activeUsers}/{systemInfo.users}
                </p>
                <p className="text-sm text-gray-500">المساحة: {systemInfo.storage}</p>
              </div>
              <Users className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Settings */}
      <Tabs defaultValue="system" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="system">النظام</TabsTrigger>
          <TabsTrigger value="security">الأمان</TabsTrigger>
          <TabsTrigger value="notifications">الإشعارات</TabsTrigger>
          <TabsTrigger value="integrations">التكاملات</TabsTrigger>
        </TabsList>

        <TabsContent value="system" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                إعدادات النظام
              </CardTitle>
              <CardDescription>إدارة الإعدادات الأساسية للنظام</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">النسخ الاحتياطي التلقائي</h4>
                  <p className="text-sm text-gray-600">إنشاء نسخ احتياطية تلقائية للبيانات</p>
                </div>
                <Switch
                  checked={settings.autoBackup}
                  onCheckedChange={(checked) => setSettings({ ...settings, autoBackup: checked })}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">تكرار النسخ الاحتياطي</label>
                <select className="w-full p-2 border rounded-md">
                  <option value="hourly">كل ساعة</option>
                  <option value="daily">يومياً</option>
                  <option value="weekly">أسبوعياً</option>
                  <option value="monthly">شهرياً</option>
                </select>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">وضع الصيانة</h4>
                  <p className="text-sm text-gray-600">تعطيل الوصول للمستخدمين مؤقتاً</p>
                </div>
                <Switch
                  checked={settings.maintenanceMode}
                  onCheckedChange={(checked) => setSettings({ ...settings, maintenanceMode: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">وضع التطوير</h4>
                  <p className="text-sm text-gray-600">تفعيل أدوات التطوير والتشخيص</p>
                </div>
                <Switch
                  checked={settings.debugMode}
                  onCheckedChange={(checked) => setSettings({ ...settings, debugMode: checked })}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                إعدادات الأمان
              </CardTitle>
              <CardDescription>إدارة أمان النظام والمصادقة</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">المصادقة الثنائية</h4>
                  <p className="text-sm text-gray-600">طبقة حماية إضافية لتسجيل الدخول</p>
                </div>
                <Switch
                  checked={settings.twoFactorAuth}
                  onCheckedChange={(checked) => setSettings({ ...settings, twoFactorAuth: checked })}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">مهلة انتهاء الجلسة (دقيقة)</label>
                <Input
                  type="number"
                  value={settings.sessionTimeout}
                  onChange={(e) => setSettings({ ...settings, sessionTimeout: Number.parseInt(e.target.value) })}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">سياسة كلمة المرور</label>
                <select className="w-full p-2 border rounded-md">
                  <option value="basic">أساسية</option>
                  <option value="medium">متوسطة</option>
                  <option value="strong">قوية</option>
                  <option value="very-strong">قوية جداً</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">عدد محاولات تسجيل الدخول المسموحة</label>
                <Input
                  type="number"
                  value={settings.loginAttempts}
                  onChange={(e) => setSettings({ ...settings, loginAttempts: Number.parseInt(e.target.value) })}
                  className="w-full"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                إعدادات الإشعارات
              </CardTitle>
              <CardDescription>إدارة طرق وأنواع الإشعارات</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-blue-600" />
                  <div>
                    <h4 className="font-medium">إشعارات البريد الإلكتروني</h4>
                    <p className="text-sm text-gray-600">إرسال الإشعارات عبر البريد</p>
                  </div>
                </div>
                <Switch
                  checked={settings.emailNotifications}
                  onCheckedChange={(checked) => setSettings({ ...settings, emailNotifications: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Bell className="w-5 h-5 text-green-600" />
                  <div>
                    <h4 className="font-medium">الإشعارات الفورية</h4>
                    <p className="text-sm text-gray-600">إشعارات فورية في المتصفح</p>
                  </div>
                </div>
                <Switch
                  checked={settings.pushNotifications}
                  onCheckedChange={(checked) => setSettings({ ...settings, pushNotifications: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Smartphone className="w-5 h-5 text-purple-600" />
                  <div>
                    <h4 className="font-medium">رسائل SMS</h4>
                    <p className="text-sm text-gray-600">إشعارات عبر الرسائل النصية</p>
                  </div>
                </div>
                <Switch
                  checked={settings.smsNotifications}
                  onCheckedChange={(checked) => setSettings({ ...settings, smsNotifications: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">صوت الإشعارات</h4>
                  <p className="text-sm text-gray-600">تشغيل صوت عند وصول إشعار</p>
                </div>
                <Switch
                  checked={settings.notificationSound}
                  onCheckedChange={(checked) => setSettings({ ...settings, notificationSound: checked })}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                التكاملات الخارجية
              </CardTitle>
              <CardDescription>إدارة التكاملات مع الخدمات الخارجية</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                {integrations.map((integration, index) => {
                  const Icon = integration.icon
                  return (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                          <Icon className="w-5 h-5 text-gray-600" />
                        </div>
                        <div>
                          <h4 className="font-medium">{integration.name}</h4>
                          <Badge className={getStatusColor(integration.status)}>{integration.status}</Badge>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        {integration.status === "متصل" ? "قطع الاتصال" : "اتصال"}
                      </Button>
                    </div>
                  )
                })}
              </div>

              <div className="border-t pt-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">الوصول للـ API</h4>
                    <p className="text-sm text-gray-600">السماح للتطبيقات الخارجية بالوصول</p>
                  </div>
                  <Switch
                    checked={settings.apiAccess}
                    onCheckedChange={(checked) => setSettings({ ...settings, apiAccess: checked })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Webhooks</h4>
                    <p className="text-sm text-gray-600">إرسال البيانات للخدمات الخارجية</p>
                  </div>
                  <Switch
                    checked={settings.webhooks}
                    onCheckedChange={(checked) => setSettings({ ...settings, webhooks: checked })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">مزامنة البيانات</h4>
                    <p className="text-sm text-gray-600">مزامنة تلقائية مع الخدمات المتصلة</p>
                  </div>
                  <Switch
                    checked={settings.dataSync}
                    onCheckedChange={(checked) => setSettings({ ...settings, dataSync: checked })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
