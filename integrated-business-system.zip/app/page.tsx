"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  BarChart3,
  Users,
  DollarSign,
  Calendar,
  Bell,
  Settings,
  Shield,
  Monitor,
  Database,
  Target,
  Zap,
  CheckCircle,
  Wrench,
  Download,
  QrCode,
} from "lucide-react"

// Import components
import DashboardOverview from "./components/dashboard-overview"
import CRMModule from "./components/crm-module"
import ERPModule from "./components/erp-module"
import AccountingModule from "./components/accounting-module"
import HRModule from "./components/hr-module"
import AttendanceAppointmentsModule from "./components/attendance-appointments-module"
import ProjectManagementModule from "./components/project-management-module"
import NotificationSystem from "./components/notification-system"
import ThemeCustomizer from "./components/theme-customizer"
import AdvancedSettings from "./components/advanced-settings"
import AIAssistant from "./components/ai-assistant"
import AdvancedReports from "./components/advanced-reports"
import TaskManagement from "./components/task-management"
import PWAInstaller from "./components/pwa-installer"
import AdvancedSecuritySystem from "./components/advanced-security-system"
import AppDownloadQR from "./components/app-download-qr"
import SystemImprovementsDashboard from "./components/system-improvements-dashboard"

export default function Home() {
  const [activeModule, setActiveModule] = useState("dashboard")
  const [showQRCode, setShowQRCode] = useState(false)
  const [showImprovements, setShowImprovements] = useState(false)

  const modules = [
    { id: "dashboard", name: "لوحة التحكم", icon: Monitor, component: DashboardOverview },
    { id: "crm", name: "إدارة العملاء", icon: Users, component: CRMModule },
    { id: "erp", name: "تخطيط الموارد", icon: Database, component: ERPModule },
    { id: "accounting", name: "المحاسبة", icon: DollarSign, component: AccountingModule },
    { id: "hr", name: "الموارد البشرية", icon: Users, component: HRModule },
    { id: "attendance", name: "الحضور والمواعيد", icon: Calendar, component: AttendanceAppointmentsModule },
    { id: "projects", name: "إدارة المشاريع", icon: Target, component: ProjectManagementModule },
    { id: "reports", name: "التقارير المتقدمة", icon: BarChart3, component: AdvancedReports },
    { id: "tasks", name: "إدارة المهام", icon: CheckCircle, component: TaskManagement },
    { id: "notifications", name: "الإشعارات", icon: Bell, component: NotificationSystem },
    { id: "security", name: "الأمان المتقدم", icon: Shield, component: AdvancedSecuritySystem },
    { id: "ai", name: "المساعد الذكي", icon: Zap, component: AIAssistant },
    { id: "theme", name: "تخصيص المظهر", icon: Settings, component: ThemeCustomizer },
    { id: "settings", name: "الإعدادات المتقدمة", icon: Settings, component: AdvancedSettings },
  ]

  const ActiveComponent = modules.find((m) => m.id === activeModule)?.component || DashboardOverview

  // Quick stats for the header
  const quickStats = [
    { label: "المستخدمون النشطون", value: "1,234", change: "+12%", color: "text-green-600" },
    { label: "المعاملات اليوم", value: "856", change: "+8%", color: "text-blue-600" },
    { label: "الإيرادات الشهرية", value: "125,000 ر.س", change: "+15%", color: "text-purple-600" },
    { label: "معدل الرضا", value: "98.5%", change: "+2%", color: "text-orange-600" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Monitor className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    GlobalBiz
                  </h1>
                  <p className="text-sm text-muted-foreground">نظام إدارة الأعمال المتكامل</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {/* Quick Stats */}
              <div className="hidden lg:flex items-center gap-6 mr-6">
                {quickStats.map((stat, index) => (
                  <div key={index} className="text-center">
                    <div className="text-sm font-semibold">{stat.value}</div>
                    <div className="text-xs text-muted-foreground">{stat.label}</div>
                    <div className={`text-xs ${stat.color}`}>{stat.change}</div>
                  </div>
                ))}
              </div>

              {/* Action Buttons */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowImprovements(!showImprovements)}
                className="gap-2"
              >
                <Wrench className="w-4 h-4" />
                التحسينات
              </Button>

              <Button variant="outline" size="sm" onClick={() => setShowQRCode(!showQRCode)} className="gap-2">
                <QrCode className="w-4 h-4" />
                تحميل التطبيق
              </Button>

              <Button size="sm" className="gap-2">
                <Bell className="w-4 h-4" />
                الإشعارات
                <Badge variant="destructive" className="ml-1">
                  3
                </Badge>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white shadow-sm border-r min-h-screen sticky top-16">
          <div className="p-4">
            <nav className="space-y-2">
              {modules.map((module) => {
                const Icon = module.icon
                return (
                  <button
                    key={module.id}
                    onClick={() => setActiveModule(module.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-right transition-colors ${
                      activeModule === module.id
                        ? "bg-blue-100 text-blue-700 border border-blue-200"
                        : "hover:bg-gray-100 text-gray-700"
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{module.name}</span>
                    {module.id === "notifications" && (
                      <Badge variant="destructive" className="mr-auto">
                        جديد
                      </Badge>
                    )}
                  </button>
                )
              })}
            </nav>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">{showImprovements ? <SystemImprovementsDashboard /> : <ActiveComponent />}</main>
      </div>

      {/* QR Code Modal */}
      {showQRCode && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">تحميل التطبيق</h3>
              <Button variant="ghost" size="sm" onClick={() => setShowQRCode(false)}>
                ✕
              </Button>
            </div>
            <AppDownloadQR />
          </div>
        </div>
      )}

      {/* PWA Installer */}
      <PWAInstaller />

      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 flex flex-col gap-3">
        <Button
          size="lg"
          className="rounded-full shadow-lg hover:shadow-xl transition-shadow"
          onClick={() => setShowQRCode(true)}
        >
          <Download className="w-5 h-5 mr-2" />
          تحميل التطبيق
        </Button>
      </div>
    </div>
  )
}
