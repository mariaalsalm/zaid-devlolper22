"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Users, UserPlus, Calendar, Clock, TrendingUp, Mail, Phone, Briefcase } from "lucide-react"

export default function HRModule() {
  const employees = [
    {
      id: 1,
      name: "أحمد محمد السالم",
      position: "مطور برمجيات",
      department: "تقنية المعلومات",
      email: "ahmed@company.com",
      phone: "+966501234567",
      joinDate: "2023-01-15",
      status: "نشط",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    {
      id: 2,
      name: "فاطمة علي أحمد",
      position: "مديرة المبيعات",
      department: "المبيعات",
      email: "fatima@company.com",
      phone: "+966507654321",
      joinDate: "2022-06-10",
      status: "نشط",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    {
      id: 3,
      name: "محمد سالم الأحمد",
      position: "محاسب",
      department: "المالية",
      email: "mohammed@company.com",
      phone: "+966551234567",
      joinDate: "2023-03-20",
      status: "إجازة",
      avatar: "/placeholder.svg?height=40&width=40",
    },
  ]

  const departments = [
    {
      name: "تقنية المعلومات",
      employees: 15,
      manager: "أحمد السالم",
      budget: "500,000 ر.س",
    },
    {
      name: "المبيعات",
      employees: 12,
      manager: "فاطمة علي",
      budget: "300,000 ر.س",
    },
    {
      name: "المالية",
      employees: 8,
      manager: "محمد سالم",
      budget: "200,000 ر.س",
    },
    {
      name: "الموارد البشرية",
      employees: 5,
      manager: "سارة أحمد",
      budget: "150,000 ر.س",
    },
  ]

  const leaveRequests = [
    {
      id: 1,
      employee: "أحمد محمد",
      type: "إجازة سنوية",
      startDate: "2024-02-01",
      endDate: "2024-02-07",
      days: 7,
      status: "معلق",
      reason: "إجازة عائلية",
    },
    {
      id: 2,
      employee: "فاطمة علي",
      type: "إجازة مرضية",
      startDate: "2024-01-20",
      endDate: "2024-01-22",
      days: 3,
      status: "موافق عليها",
      reason: "إجازة مرضية",
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "نشط":
      case "موافق عليها":
        return "bg-green-100 text-green-800"
      case "إجازة":
      case "معلق":
        return "bg-yellow-100 text-yellow-800"
      case "مرفوضة":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">إدارة الموارد البشرية</h1>
          <p className="text-gray-600 mt-1">إدارة الموظفين والأقسام والإجازات</p>
        </div>
        <Button className="gap-2">
          <UserPlus className="w-4 h-4" />
          إضافة موظف جديد
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">إجمالي الموظفين</p>
                <p className="text-2xl font-bold text-gray-900">156</p>
              </div>
              <Users className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">الموظفون النشطون</p>
                <p className="text-2xl font-bold text-gray-900">142</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">طلبات الإجازة</p>
                <p className="text-2xl font-bold text-gray-900">23</p>
              </div>
              <Calendar className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">معدل الحضور</p>
                <p className="text-2xl font-bold text-gray-900">96.5%</p>
              </div>
              <Clock className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="employees" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="employees">الموظفون</TabsTrigger>
          <TabsTrigger value="departments">الأقسام</TabsTrigger>
          <TabsTrigger value="leaves">الإجازات</TabsTrigger>
        </TabsList>

        <TabsContent value="employees" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>قائمة الموظفين</CardTitle>
              <CardDescription>جميع الموظفين المسجلين في النظام</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {employees.map((employee) => (
                  <div key={employee.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={employee.avatar || "/placeholder.svg"} alt={employee.name} />
                        <AvatarFallback>{employee.name.split(" ")[0][0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold text-gray-900">{employee.name}</h3>
                        <p className="text-sm text-gray-600">{employee.position}</p>
                        <div className="flex items-center gap-4 text-xs text-gray-500 mt-1">
                          <span className="flex items-center gap-1">
                            <Briefcase className="w-3 h-3" />
                            {employee.department}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            انضم في {employee.joinDate}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-left">
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Mail className="w-4 h-4" />
                          {employee.email}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
                          <Phone className="w-4 h-4" />
                          {employee.phone}
                        </div>
                      </div>
                      <Badge className={getStatusColor(employee.status)}>{employee.status}</Badge>
                      <Button variant="outline" size="sm">
                        عرض الملف
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="departments" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {departments.map((dept, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Briefcase className="w-5 h-5" />
                    {dept.name}
                  </CardTitle>
                  <CardDescription>مدير القسم: {dept.manager}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">عدد الموظفين</span>
                      <span className="font-semibold">{dept.employees}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">الميزانية</span>
                      <span className="font-semibold">{dept.budget}</span>
                    </div>
                    <Button variant="outline" className="w-full mt-4 bg-transparent">
                      عرض تفاصيل القسم
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="leaves" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>طلبات الإجازة</CardTitle>
              <CardDescription>جميع طلبات الإجازة المقدمة من الموظفين</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {leaveRequests.map((request) => (
                  <div key={request.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <Calendar className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{request.employee}</h3>
                        <p className="text-sm text-gray-600">{request.type}</p>
                        <p className="text-xs text-gray-500 mt-1">{request.reason}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-600">من</p>
                        <p className="text-sm font-medium">{request.startDate}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600">إلى</p>
                        <p className="text-sm font-medium">{request.endDate}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600">الأيام</p>
                        <p className="font-bold text-lg">{request.days}</p>
                      </div>
                      <Badge className={getStatusColor(request.status)}>{request.status}</Badge>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="text-green-600 bg-transparent">
                          موافقة
                        </Button>
                        <Button variant="outline" size="sm" className="text-red-600 bg-transparent">
                          رفض
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
