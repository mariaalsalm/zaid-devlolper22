"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Smartphone, Monitor, Download, QrCode, Apple, Globe, Star, Shield, Zap } from "lucide-react"

export default function AppDownloadQR() {
  const appInfo = {
    version: "2.1.0",
    size: "45.2 MB",
    rating: 4.8,
    downloads: "10K+",
    lastUpdate: "2024-01-15",
  }

  const features = [
    { icon: Zap, title: "أداء سريع", description: "تحميل فوري وتجربة سلسة" },
    { icon: Shield, title: "أمان عالي", description: "حماية متقدمة للبيانات" },
    { icon: Globe, title: "يعمل بدون إنترنت", description: "وصول للبيانات حتى بدون اتصال" },
    { icon: Star, title: "واجهة حديثة", description: "تصميم عصري وسهل الاستخدام" },
  ]

  const downloadOptions = [
    {
      platform: "Android",
      icon: Smartphone,
      color: "text-green-600",
      bgColor: "bg-green-100",
      qrCode: "/placeholder.svg?height=150&width=150&text=Android+QR",
      url: "https://play.google.com/store/apps/details?id=com.globalbiz.app",
      instructions: "امسح الكود أو ابحث عن 'GlobalBiz' في متجر Google Play",
    },
    {
      platform: "iPhone/iPad",
      icon: Apple,
      color: "text-gray-800",
      bgColor: "bg-gray-100",
      qrCode: "/placeholder.svg?height=150&width=150&text=iOS+QR",
      url: "https://apps.apple.com/app/globalbiz/id123456789",
      instructions: "امسح الكود أو ابحث عن 'GlobalBiz' في App Store",
    },
    {
      platform: "الويب",
      icon: Globe,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
      qrCode: "/placeholder.svg?height=150&width=150&text=Web+QR",
      url: "https://app.globalbiz.com",
      instructions: "امسح الكود للوصول المباشر للتطبيق عبر المتصفح",
    },
  ]

  const systemRequirements = {
    android: {
      os: "Android 8.0+",
      ram: "2 GB RAM",
      storage: "100 MB",
      processor: "ARM64 أو x86",
    },
    ios: {
      os: "iOS 13.0+",
      ram: "2 GB RAM",
      storage: "100 MB",
      processor: "A10 Bionic أو أحدث",
    },
    web: {
      browser: "Chrome 90+, Safari 14+, Firefox 88+",
      ram: "1 GB RAM",
      storage: "50 MB",
      connection: "اتصال إنترنت مستقر",
    },
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* App Info Header */}
      <div className="text-center space-y-4">
        <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl mx-auto flex items-center justify-center">
          <Monitor className="w-10 h-10 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">GlobalBiz</h2>
          <p className="text-gray-600">نظام إدارة الأعمال المتكامل</p>
        </div>

        <div className="flex items-center justify-center gap-6 text-sm">
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 text-yellow-500" />
            <span className="font-semibold">{appInfo.rating}</span>
          </div>
          <div className="text-gray-600">الإصدار {appInfo.version}</div>
          <div className="text-gray-600">{appInfo.size}</div>
          <div className="text-gray-600">{appInfo.downloads} تحميل</div>
        </div>
      </div>

      {/* Features */}
      <div className="grid grid-cols-2 gap-4">
        {features.map((feature, index) => {
          const Icon = feature.icon
          return (
            <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <Icon className="w-4 h-4 text-blue-600" />
              </div>
              <div>
                <h4 className="font-medium text-sm">{feature.title}</h4>
                <p className="text-xs text-gray-600">{feature.description}</p>
              </div>
            </div>
          )
        })}
      </div>

      {/* Download Options */}
      <Tabs defaultValue="android" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="android">Android</TabsTrigger>
          <TabsTrigger value="ios">iPhone</TabsTrigger>
          <TabsTrigger value="web">الويب</TabsTrigger>
        </TabsList>

        {downloadOptions.map((option, index) => {
          const Icon = option.icon
          const tabValue = option.platform.toLowerCase().replace("/", "").replace(" ", "")

          return (
            <TabsContent key={index} value={tabValue === "iphoneipad" ? "ios" : tabValue} className="space-y-4">
              <Card>
                <CardHeader className="text-center">
                  <div
                    className={`w-16 h-16 ${option.bgColor} rounded-2xl mx-auto flex items-center justify-center mb-3`}
                  >
                    <Icon className={`w-8 h-8 ${option.color}`} />
                  </div>
                  <CardTitle className="flex items-center justify-center gap-2">
                    {option.platform}
                    <Badge variant="outline">مجاني</Badge>
                  </CardTitle>
                  <CardDescription>{option.instructions}</CardDescription>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* QR Code */}
                  <div className="text-center">
                    <div className="w-40 h-40 bg-white border-2 border-gray-200 rounded-lg mx-auto flex items-center justify-center mb-3">
                      <div className="w-32 h-32 bg-gray-100 rounded flex items-center justify-center">
                        <QrCode className="w-16 h-16 text-gray-400" />
                      </div>
                    </div>
                    <p className="text-sm text-gray-600">امسح الكود بكاميرا هاتفك</p>
                  </div>

                  {/* Direct Download Button */}
                  <Button className="w-full gap-2" onClick={() => window.open(option.url, "_blank")}>
                    <Download className="w-4 h-4" />
                    تحميل مباشر
                  </Button>

                  {/* System Requirements */}
                  <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                    <h4 className="font-medium text-sm mb-2">متطلبات النظام:</h4>
                    {tabValue === "android" && (
                      <div className="space-y-1 text-xs text-gray-600">
                        <p>• نظام التشغيل: {systemRequirements.android.os}</p>
                        <p>• الذاكرة: {systemRequirements.android.ram}</p>
                        <p>• التخزين: {systemRequirements.android.storage}</p>
                        <p>• المعالج: {systemRequirements.android.processor}</p>
                      </div>
                    )}
                    {tabValue === "ios" && (
                      <div className="space-y-1 text-xs text-gray-600">
                        <p>• نظام التشغيل: {systemRequirements.ios.os}</p>
                        <p>• الذاكرة: {systemRequirements.ios.ram}</p>
                        <p>• التخزين: {systemRequirements.ios.storage}</p>
                        <p>• المعالج: {systemRequirements.ios.processor}</p>
                      </div>
                    )}
                    {tabValue === "web" && (
                      <div className="space-y-1 text-xs text-gray-600">
                        <p>• المتصفح: {systemRequirements.web.browser}</p>
                        <p>• الذاكرة: {systemRequirements.web.ram}</p>
                        <p>• التخزين: {systemRequirements.web.storage}</p>
                        <p>• الاتصال: {systemRequirements.web.connection}</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )
        })}
      </Tabs>

      {/* Additional Info */}
      <div className="bg-blue-50 rounded-lg p-4 text-center">
        <h4 className="font-medium text-blue-900 mb-2">💡 نصيحة</h4>
        <p className="text-sm text-blue-800">للحصول على أفضل تجربة، ننصح بتحميل التطبيق الأصلي على هاتفك المحمول</p>
      </div>

      {/* Security Notice */}
      <div className="bg-green-50 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <Shield className="w-4 h-4 text-green-600" />
          <h4 className="font-medium text-green-900">أمان وخصوصية</h4>
        </div>
        <p className="text-sm text-green-800">
          جميع التطبيقات محمية بتشفير من الدرجة المصرفية وتلتزم بأعلى معايير الأمان والخصوصية
        </p>
      </div>
    </div>
  )
}
