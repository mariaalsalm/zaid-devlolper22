"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Palette, Sun, Moon, Monitor, Zap, Eye, Type, Layout, Settings } from "lucide-react"

export default function ThemeCustomizer() {
  const [isOpen, setIsOpen] = useState(false)
  const [settings, setSettings] = useState({
    darkMode: false,
    autoTheme: true,
    fontSize: 16,
    compactMode: false,
    animations: true,
    highContrast: false,
    rtlSupport: true,
    colorScheme: "blue",
  })

  const colorSchemes = [
    { name: "أزرق", value: "blue", color: "bg-blue-500" },
    { name: "أخضر", value: "green", color: "bg-green-500" },
    { name: "بنفسجي", value: "purple", color: "bg-purple-500" },
    { name: "برتقالي", value: "orange", color: "bg-orange-500" },
    { name: "أحمر", value: "red", color: "bg-red-500" },
    { name: "رمادي", value: "gray", color: "bg-gray-500" },
  ]

  const presets = [
    { name: "افتراضي", description: "التصميم الافتراضي للنظام" },
    { name: "مظلم", description: "مظهر مظلم مريح للعينين" },
    { name: "عالي التباين", description: "تباين عالي لسهولة القراءة" },
    { name: "مضغوط", description: "واجهة مضغوطة لتوفير المساحة" },
  ]

  if (!isOpen) {
    return (
      <div className="fixed top-1/2 left-4 transform -translate-y-1/2 z-40">
        <Button
          onClick={() => setIsOpen(true)}
          variant="outline"
          size="sm"
          className="rounded-full shadow-lg bg-white/90 backdrop-blur-sm border-gray-200 hover:bg-white"
        >
          <Palette className="w-4 h-4" />
        </Button>
      </div>
    )
  }

  return (
    <div className="fixed top-1/2 left-4 transform -translate-y-1/2 z-40 w-80" dir="rtl">
      <Card className="shadow-2xl border-0 bg-white/95 backdrop-blur-sm">
        <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-t-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                <Palette className="w-5 h-5" />
              </div>
              <div>
                <CardTitle className="text-lg">تخصيص المظهر</CardTitle>
                <CardDescription className="text-white/80">خصص واجهة النظام</CardDescription>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)} className="text-white hover:bg-white/20">
              ✕
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
          {/* Theme Mode */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
              <Sun className="w-4 h-4" />
              وضع المظهر
            </h3>
            <div className="grid grid-cols-3 gap-2">
              <Button
                variant={!settings.darkMode && !settings.autoTheme ? "default" : "outline"}
                size="sm"
                className="flex-col gap-1 h-auto py-3"
                onClick={() => setSettings({ ...settings, darkMode: false, autoTheme: false })}
              >
                <Sun className="w-4 h-4" />
                <span className="text-xs">فاتح</span>
              </Button>
              <Button
                variant={settings.darkMode && !settings.autoTheme ? "default" : "outline"}
                size="sm"
                className="flex-col gap-1 h-auto py-3"
                onClick={() => setSettings({ ...settings, darkMode: true, autoTheme: false })}
              >
                <Moon className="w-4 h-4" />
                <span className="text-xs">مظلم</span>
              </Button>
              <Button
                variant={settings.autoTheme ? "default" : "outline"}
                size="sm"
                className="flex-col gap-1 h-auto py-3"
                onClick={() => setSettings({ ...settings, autoTheme: true })}
              >
                <Monitor className="w-4 h-4" />
                <span className="text-xs">تلقائي</span>
              </Button>
            </div>
          </div>

          {/* Color Scheme */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
              <Palette className="w-4 h-4" />
              نظام الألوان
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {colorSchemes.map((scheme) => (
                <Button
                  key={scheme.value}
                  variant={settings.colorScheme === scheme.value ? "default" : "outline"}
                  size="sm"
                  className="flex-col gap-1 h-auto py-3"
                  onClick={() => setSettings({ ...settings, colorScheme: scheme.value })}
                >
                  <div className={`w-4 h-4 rounded-full ${scheme.color}`}></div>
                  <span className="text-xs">{scheme.name}</span>
                </Button>
              ))}
            </div>
          </div>

          {/* Font Size */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
              <Type className="w-4 h-4" />
              حجم الخط
            </h3>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>صغير</span>
                <span>{settings.fontSize}px</span>
                <span>كبير</span>
              </div>
              <Slider
                value={[settings.fontSize]}
                onValueChange={(value) => setSettings({ ...settings, fontSize: value[0] })}
                min={12}
                max={20}
                step={1}
                className="w-full"
              />
            </div>
          </div>

          {/* Settings Toggles */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
              <Settings className="w-4 h-4" />
              إعدادات إضافية
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Layout className="w-4 h-4 text-gray-500" />
                  <span className="text-sm">الوضع المضغوط</span>
                </div>
                <Switch
                  checked={settings.compactMode}
                  onCheckedChange={(checked) => setSettings({ ...settings, compactMode: checked })}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-gray-500" />
                  <span className="text-sm">الحركات المتحركة</span>
                </div>
                <Switch
                  checked={settings.animations}
                  onCheckedChange={(checked) => setSettings({ ...settings, animations: checked })}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Eye className="w-4 h-4 text-gray-500" />
                  <span className="text-sm">التباين العالي</span>
                </div>
                <Switch
                  checked={settings.highContrast}
                  onCheckedChange={(checked) => setSettings({ ...settings, highContrast: checked })}
                />
              </div>
            </div>
          </div>

          {/* Presets */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900">القوالب الجاهزة</h3>
            <div className="space-y-2">
              {presets.map((preset, index) => (
                <Button key={index} variant="outline" className="w-full justify-start h-auto py-3 bg-transparent">
                  <div className="text-right">
                    <div className="font-medium text-sm">{preset.name}</div>
                    <div className="text-xs text-gray-500">{preset.description}</div>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-4 border-t">
            <Button variant="outline" className="flex-1 bg-transparent">
              إعادة تعيين
            </Button>
            <Button className="flex-1">حفظ التغييرات</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
