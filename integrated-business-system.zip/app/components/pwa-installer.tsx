"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, Smartphone, Monitor, Wifi, Bell, X, CheckCircle } from "lucide-react"

export default function PWAInstaller() {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)
  const [showInstallPrompt, setShowInstallPrompt] = useState(false)
  const [isInstalled, setIsInstalled] = useState(false)
  const [isStandalone, setIsStandalone] = useState(false)

  useEffect(() => {
    // Check if app is already installed
    setIsStandalone(window.matchMedia("(display-mode: standalone)").matches)
    setIsInstalled(localStorage.getItem("pwa-installed") === "true")

    // Listen for the beforeinstallprompt event
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e)
      if (!isInstalled && !isStandalone) {
        setShowInstallPrompt(true)
      }
    }

    // Listen for app installed event
    const handleAppInstalled = () => {
      setIsInstalled(true)
      setShowInstallPrompt(false)
      localStorage.setItem("pwa-installed", "true")
    }

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
    window.addEventListener("appinstalled", handleAppInstalled)

    // Show install prompt after 30 seconds if not installed
    const timer = setTimeout(() => {
      if (!isInstalled && !isStandalone && deferredPrompt) {
        setShowInstallPrompt(true)
      }
    }, 30000)

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
      window.removeEventListener("appinstalled", handleAppInstalled)
      clearTimeout(timer)
    }
  }, [isInstalled, isStandalone, deferredPrompt])

  const handleInstallClick = async () => {
    if (!deferredPrompt) return

    deferredPrompt.prompt()
    const { outcome } = await deferredPrompt.userChoice

    if (outcome === "accepted") {
      setIsInstalled(true)
      localStorage.setItem("pwa-installed", "true")
    }

    setDeferredPrompt(null)
    setShowInstallPrompt(false)
  }

  const handleDismiss = () => {
    setShowInstallPrompt(false)
    localStorage.setItem("pwa-dismissed", "true")
  }

  // Don't show if already installed or in standalone mode
  if (isInstalled || isStandalone || !showInstallPrompt) {
    return null
  }

  return (
    <div className="fixed bottom-20 right-6 z-50 w-80" dir="rtl">
      <Card className="shadow-2xl border-0 bg-white/95 backdrop-blur-sm">
        <CardHeader className="bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-t-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <Download className="w-6 h-6" />
              </div>
              <div>
                <CardTitle className="text-lg">تثبيت التطبيق</CardTitle>
                <CardDescription className="text-white/80">للحصول على تجربة أفضل</CardDescription>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={handleDismiss} className="text-white hover:bg-white/20">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-6 space-y-4">
          <div className="text-center">
            <h3 className="font-semibold text-gray-900 mb-2">ثبت GlobalBiz على جهازك</h3>
            <p className="text-sm text-gray-600 mb-4">احصل على تجربة تطبيق أصلي مع ميزات متقدمة</p>
          </div>

          {/* Features */}
          <div className="space-y-3">
            <div className="flex items-center gap-3 text-sm">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <Wifi className="w-4 h-4 text-blue-600" />
              </div>
              <span>يعمل بدون إنترنت</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                <Bell className="w-4 h-4 text-green-600" />
              </div>
              <span>إشعارات فورية</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                <Smartphone className="w-4 h-4 text-purple-600" />
              </div>
              <span>تجربة تطبيق أصلي</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                <Monitor className="w-4 h-4 text-orange-600" />
              </div>
              <span>يعمل على جميع الأجهزة</span>
            </div>
          </div>

          {/* Device Detection */}
          <div className="bg-gray-50 rounded-lg p-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">نوع الجهاز:</span>
              <Badge variant="outline" className="gap-1">
                {/Android/i.test(navigator.userAgent) ? (
                  <>
                    <Smartphone className="w-3 h-3" />
                    أندرويد
                  </>
                ) : /iPhone|iPad|iPod/i.test(navigator.userAgent) ? (
                  <>
                    <Smartphone className="w-3 h-3" />
                    iOS
                  </>
                ) : (
                  <>
                    <Monitor className="w-3 h-3" />
                    سطح المكتب
                  </>
                )}
              </Badge>
            </div>
          </div>

          {/* Install Instructions */}
          <div className="text-xs text-gray-500 bg-blue-50 rounded-lg p-3">
            <p className="font-medium text-blue-800 mb-1">كيفية التثبيت:</p>
            {/iPhone|iPad|iPod/i.test(navigator.userAgent) ? (
              <p>اضغط على زر المشاركة في Safari ثم "إضافة إلى الشاشة الرئيسية"</p>
            ) : (
              <p>اضغط على "تثبيت" أدناه لإضافة التطبيق إلى جهازك</p>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 pt-2">
            <Button variant="outline" onClick={handleDismiss} className="flex-1 bg-transparent">
              لاحقاً
            </Button>
            <Button
              onClick={handleInstallClick}
              className="flex-1 bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
            >
              <Download className="w-4 h-4 mr-2" />
              تثبيت الآن
            </Button>
          </div>

          {/* Success Message */}
          {isInstalled && (
            <div className="flex items-center gap-2 text-green-600 bg-green-50 rounded-lg p-3">
              <CheckCircle className="w-4 h-4" />
              <span className="text-sm font-medium">تم التثبيت بنجاح!</span>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
