"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart3,
  PieChart,
  TrendingUp,
  Download,
  Calendar,
  Filter,
  FileText,
  DollarSign,
  Users,
  Package,
} from "lucide-react"

export default function AdvancedReports() {
  const reportCategories = [
    {
      id: "financial",
      name: "التقارير المالية",
      icon: DollarSign,
      color: "text-green-600",
      bgColor: "bg-green-100",
      reports: [
        { name: "تقرير الأرباح والخسائر", description: "تحليل الإيرادات والمصروفات", lastGenerated: "2024-01-15" },
        { name: "التدفق النقدي", description: "حركة الأموال الداخلة والخارجة", lastGenerated: "2024-01-14" },
        { name: "الميزانية العمومية", description: "الأصول والخصوم وحقوق الملكية", lastGenerated: "2024-01-13" },
      ],
    },
    {
      id: "sales",
      name: "تقارير المبيعات",
      icon: TrendingUp,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
      reports: [
        { name: "أداء المبيعات الشهري", description: "تحليل مبيعات الشهر الحالي", lastGenerated: "2024-01-16" },
        { name: "تقرير العملاء", description: "تحليل سلوك وأداء العملاء", lastGenerated: "2024-01-15" },
        { name: "تحليل المنتجات", description: "أداء المنتجات والخدمات", lastGenerated: "2024-01-14" },
      ],
    },
    {
      id: "hr",
      name: "تقارير الموارد البشرية",
      icon: Users,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
      reports: [
        { name: "تقرير الحضور والغياب", description: "إحصائيات حضور الموظفين", lastGenerated: "2024-01-16" },
        { name: "تقييم الأداء", description: "تقييمات الموظفين والإنتاجية", lastGenerated: "2024-01-12" },
        { name: "تقرير الرواتب", description: "تفاصيل الرواتب والمكافآت", lastGenerated: "2024-01-10" },
      ],
    },
    {
      id: "inventory",
      name: "تقارير المخزون",
      icon: Package,
      color: "text-orange-600",
      bgColor: "bg-orange-100",
      reports: [
        { name: "حالة المخزون", description: "الكميات المتوفرة والمطلوبة", lastGenerated: "2024-01-16" },
        { name: "حركة المخزون", description: "المدخلات والمخرجات", lastGenerated: "2024-01-15" },
        { name: "تقرير التكاليف", description: "تكاليف المخزون والتقييم", lastGenerated: "2024-01-13" },
      ],
    },
  ]

  const quickStats = [
    { label: "التقارير المُنشأة هذا الشهر", value: "156", change: "+23%", color: "text-green-600" },
    { label: "التقارير المجدولة", value: "12", change: "+2", color: "text-blue-600" },
    { label: "التقارير المشتركة", value: "45", change: "+8%", color: "text-purple-600" },
    { label: "متوسط وقت الإنشاء", value: "2.3 ثانية", change: "-15%", color: "text-orange-600" },
  ]

  const recentReports = [
    {
      id: 1,
      name: "تقرير المبيعات الأسبوعي",
      type: "مبيعات",
      generatedBy: "أحمد محمد",
      date: "2024-01-16",
      size: "2.3 MB",
      status: "مكتمل",
    },
    {
      id: 2,
      name: "تحليل الأرباح الشهري",
      type: "مالي",
      generatedBy: "فاطمة علي",
      date: "2024-01-15",
      size: "1.8 MB",
      status: "مكتمل",
    },
    {
      id: 3,
      name: "تقرير حضور الموظفين",
      type: "موارد بشرية",
      generatedBy: "محمد سالم",
      date: "2024-01-14",
      size: "956 KB",
      status: "قيد المعالجة",
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "مكتمل":
        return "bg-green-100 text-green-800"
      case "قيد المعالجة":
        return "bg-yellow-100 text-yellow-800"
      case "فشل":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">التقارير المتقدمة</h1>
          <p className="text-gray-600 mt-1">إنشاء وإدارة التقارير التفاعلية</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2 bg-transparent">
            <Filter className="w-4 h-4" />
            تصفية
          </Button>
          <Button variant="outline" className="gap-2 bg-transparent">
            <Calendar className="w-4 h-4" />
            جدولة تقرير
          </Button>
          <Button className="gap-2">
            <FileText className="w-4 h-4" />
            تقرير جديد
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {quickStats.map((stat, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-sm text-gray-600 mt-1">{stat.label}</p>
                <p className={`text-sm font-medium mt-2 ${stat.color}`}>{stat.change}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content */}
      <Tabs defaultValue="categories" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="categories">فئات التقارير</TabsTrigger>
          <TabsTrigger value="recent">التقارير الأخيرة</TabsTrigger>
          <TabsTrigger value="analytics">التحليلات</TabsTrigger>
        </TabsList>

        <TabsContent value="categories" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {reportCategories.map((category) => {
              const Icon = category.icon
              return (
                <Card key={category.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${category.bgColor}`}>
                        <Icon className={`w-6 h-6 ${category.color}`} />
                      </div>
                      {category.name}
                    </CardTitle>
                    <CardDescription>{category.reports.length} تقرير متاح</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {category.reports.map((report, index) => (
                        <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <h4 className="font-medium text-gray-900">{report.name}</h4>
                            <p className="text-sm text-gray-600">{report.description}</p>
                            <p className="text-xs text-gray-500 mt-1">آخر إنشاء: {report.lastGenerated}</p>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              <BarChart3 className="w-4 h-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Download className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="recent" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>التقارير المُنشأة مؤخراً</CardTitle>
              <CardDescription>آخر التقارير التي تم إنشاؤها في النظام</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentReports.map((report) => (
                  <div key={report.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <FileText className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{report.name}</h3>
                        <p className="text-sm text-gray-600">
                          {report.type} • بواسطة {report.generatedBy}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          {report.date} • {report.size}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <Badge className={getStatusColor(report.status)}>{report.status}</Badge>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <BarChart3 className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="w-5 h-5" />
                  توزيع التقارير حسب النوع
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">التقارير المالية</span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 bg-gray-200 rounded-full">
                        <div className="w-12 h-2 bg-green-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">45%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">تقارير المبيعات</span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 bg-gray-200 rounded-full">
                        <div className="w-10 h-2 bg-blue-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">30%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">الموارد البشرية</span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 bg-gray-200 rounded-full">
                        <div className="w-6 h-2 bg-purple-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">15%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">المخزون</span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 bg-gray-200 rounded-full">
                        <div className="w-4 h-2 bg-orange-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">10%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  إحصائيات الاستخدام
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">التقارير اليومية</span>
                  <span className="font-semibold">12</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">التقارير الأسبوعية</span>
                  <span className="font-semibold">45</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">التقارير الشهرية</span>
                  <span className="font-semibold">156</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">المستخدمون النشطون</span>
                  <span className="font-semibold">23</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">متوسط حجم التقرير</span>
                  <span className="font-semibold">1.8 MB</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
