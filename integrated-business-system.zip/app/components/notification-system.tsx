"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Bell,
  Mail,
  MessageSquare,
  AlertTriangle,
  CheckCircle,
  Clock,
  Settings,
  Trash2,
  BookMarkedIcon as MarkAsUnread,
} from "lucide-react"

export default function NotificationSystem() {
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      title: "فاتورة جديدة تم إنشاؤها",
      message: "تم إنشاء فاتورة رقم INV-001 بقيمة 15,000 ر.س",
      type: "info",
      time: "منذ 5 دقائق",
      read: false,
      category: "المحاسبة",
    },
    {
      id: 2,
      title: "موعد اجتماع قادم",
      message: "اجتماع مع شركة الأمل للتجارة غداً الساعة 10:00 صباحاً",
      type: "warning",
      time: "منذ 15 دقيقة",
      read: false,
      category: "المواعيد",
    },
    {
      id: 3,
      title: "تم إكمال مهمة",
      message: "أحمد محمد أكمل مهمة تصميم واجهة المستخدم",
      type: "success",
      time: "منذ 30 دقيقة",
      read: true,
      category: "المشاريع",
    },
    {
      id: 4,
      title: "تنبيه مخزون منخفض",
      message: "منتج HP LaserJet وصل إلى الحد الأدنى للمخزون",
      type: "error",
      time: "منذ ساعة",
      read: false,
      category: "المخزون",
    },
  ])

  const [settings, setSettings] = useState({
    emailNotifications: true,
    pushNotifications: true,
    smsNotifications: false,
    invoiceAlerts: true,
    appointmentReminders: true,
    taskUpdates: true,
    inventoryAlerts: true,
  })

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle className="w-5 h-5 text-green-600" />
      case "warning":
        return <AlertTriangle className="w-5 h-5 text-yellow-600" />
      case "error":
        return <AlertTriangle className="w-5 h-5 text-red-600" />
      default:
        return <Bell className="w-5 h-5 text-blue-600" />
    }
  }

  const getNotificationColor = (type: string) => {
    switch (type) {
      case "success":
        return "border-r-green-500"
      case "warning":
        return "border-r-yellow-500"
      case "error":
        return "border-r-red-500"
      default:
        return "border-r-blue-500"
    }
  }

  const markAsRead = (id: number) => {
    setNotifications(notifications.map((notif) => (notif.id === id ? { ...notif, read: true } : notif)))
  }

  const deleteNotification = (id: number) => {
    setNotifications(notifications.filter((notif) => notif.id !== id))
  }

  const unreadCount = notifications.filter((n) => !n.read).length

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">مركز الإشعارات</h1>
          <p className="text-gray-600 mt-1">إدارة جميع الإشعارات والتنبيهات</p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="destructive" className="gap-1">
            <Bell className="w-4 h-4" />
            {unreadCount} غير مقروء
          </Badge>
          <Button variant="outline" className="gap-2 bg-transparent">
            <Settings className="w-4 h-4" />
            الإعدادات
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">إجمالي الإشعارات</p>
                <p className="text-2xl font-bold text-gray-900">{notifications.length}</p>
              </div>
              <Bell className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">غير مقروءة</p>
                <p className="text-2xl font-bold text-red-600">{unreadCount}</p>
              </div>
              <MarkAsUnread className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">اليوم</p>
                <p className="text-2xl font-bold text-green-600">12</p>
              </div>
              <Clock className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">التنبيهات المهمة</p>
                <p className="text-2xl font-bold text-orange-600">3</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="notifications" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="notifications">الإشعارات</TabsTrigger>
          <TabsTrigger value="settings">إعدادات الإشعارات</TabsTrigger>
        </TabsList>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>الإشعارات الأخيرة</CardTitle>
              <CardDescription>جميع الإشعارات والتنبيهات الواردة</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`flex items-start justify-between p-4 border-r-4 rounded-lg ${
                      notification.read ? "bg-gray-50" : "bg-white border shadow-sm"
                    } ${getNotificationColor(notification.type)}`}
                  >
                    <div className="flex items-start gap-4">
                      <div className="mt-1">{getNotificationIcon(notification.type)}</div>
                      <div className="flex-1">
                        <h3 className={`font-semibold ${notification.read ? "text-gray-600" : "text-gray-900"}`}>
                          {notification.title}
                        </h3>
                        <p className={`text-sm mt-1 ${notification.read ? "text-gray-500" : "text-gray-700"}`}>
                          {notification.message}
                        </p>
                        <div className="flex items-center gap-4 mt-2">
                          <span className="text-xs text-gray-500">{notification.time}</span>
                          <Badge variant="outline" className="text-xs">
                            {notification.category}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {!notification.read && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => markAsRead(notification.id)}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          تم القراءة
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteNotification(notification.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>طرق الإشعار</CardTitle>
                <CardDescription>اختر كيفية تلقي الإشعارات</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-blue-600" />
                    <span>إشعارات البريد الإلكتروني</span>
                  </div>
                  <Switch
                    checked={settings.emailNotifications}
                    onCheckedChange={(checked) => setSettings({ ...settings, emailNotifications: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Bell className="w-5 h-5 text-green-600" />
                    <span>الإشعارات الفورية</span>
                  </div>
                  <Switch
                    checked={settings.pushNotifications}
                    onCheckedChange={(checked) => setSettings({ ...settings, pushNotifications: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <MessageSquare className="w-5 h-5 text-purple-600" />
                    <span>رسائل SMS</span>
                  </div>
                  <Switch
                    checked={settings.smsNotifications}
                    onCheckedChange={(checked) => setSettings({ ...settings, smsNotifications: checked })}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>أنواع الإشعارات</CardTitle>
                <CardDescription>اختر أنواع الإشعارات التي تريد تلقيها</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>تنبيهات الفواتير</span>
                  <Switch
                    checked={settings.invoiceAlerts}
                    onCheckedChange={(checked) => setSettings({ ...settings, invoiceAlerts: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span>تذكير المواعيد</span>
                  <Switch
                    checked={settings.appointmentReminders}
                    onCheckedChange={(checked) => setSettings({ ...settings, appointmentReminders: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span>تحديثات المهام</span>
                  <Switch
                    checked={settings.taskUpdates}
                    onCheckedChange={(checked) => setSettings({ ...settings, taskUpdates: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span>تنبيهات المخزون</span>
                  <Switch
                    checked={settings.inventoryAlerts}
                    onCheckedChange={(checked) => setSettings({ ...settings, inventoryAlerts: checked })}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
