"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Package, Truck, ShoppingCart, AlertTriangle, TrendingUp } from "lucide-react"

export default function ERPModule() {
  const inventory = [
    {
      id: 1,
      name: "لابتوب Dell XPS 13",
      sku: "DELL-XPS-001",
      quantity: 25,
      minStock: 10,
      price: "4,500 ر.س",
      status: "متوفر",
    },
    {
      id: 2,
      name: "طابعة HP LaserJet",
      sku: "HP-LJ-002",
      quantity: 5,
      minStock: 10,
      price: "1,200 ر.س",
      status: "نفاد قريب",
    },
    {
      id: 3,
      name: "شاشة Samsung 27 بوصة",
      sku: "SAM-MON-003",
      quantity: 0,
      minStock: 5,
      price: "1,800 ر.س",
      status: "نفد المخزون",
    },
  ]

  const orders = [
    {
      id: "ORD-001",
      customer: "شركة الأمل للتجارة",
      items: 5,
      total: "15,000 ر.س",
      status: "قيد التجهيز",
      date: "2024-01-15",
    },
    {
      id: "ORD-002",
      customer: "مؤسسة النور",
      items: 3,
      total: "8,500 ر.س",
      status: "تم الشحن",
      date: "2024-01-14",
    },
    {
      id: "ORD-003",
      customer: "محمد أحمد",
      items: 2,
      total: "3,200 ر.س",
      status: "مكتمل",
      date: "2024-01-13",
    },
  ]

  const suppliers = [
    {
      id: 1,
      name: "شركة التقنية المتقدمة",
      products: 45,
      orders: 12,
      rating: 4.8,
      status: "نشط",
    },
    {
      id: 2,
      name: "مؤسسة الإلكترونيات",
      products: 32,
      orders: 8,
      rating: 4.5,
      status: "نشط",
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "متوفر":
      case "نشط":
      case "مكتمل":
        return "bg-green-100 text-green-800"
      case "نفاد قريب":
      case "قيد التجهيز":
        return "bg-yellow-100 text-yellow-800"
      case "نفد المخزون":
        return "bg-red-100 text-red-800"
      case "تم الشحن":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">تخطيط موارد المؤسسة</h1>
          <p className="text-gray-600 mt-1">إدارة المخزون والطلبات والموردين</p>
        </div>
        <Button className="gap-2">
          <Package className="w-4 h-4" />
          إضافة منتج جديد
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">إجمالي المنتجات</p>
                <p className="text-2xl font-bold text-gray-900">1,245</p>
              </div>
              <Package className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">الطلبات النشطة</p>
                <p className="text-2xl font-bold text-gray-900">156</p>
              </div>
              <ShoppingCart className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">تنبيهات المخزون</p>
                <p className="text-2xl font-bold text-gray-900">23</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">قيمة المخزون</p>
                <p className="text-2xl font-bold text-gray-900">2.8M ر.س</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="inventory" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="inventory">المخزون</TabsTrigger>
          <TabsTrigger value="orders">الطلبات</TabsTrigger>
          <TabsTrigger value="suppliers">الموردون</TabsTrigger>
        </TabsList>

        <TabsContent value="inventory" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>إدارة المخزون</CardTitle>
              <CardDescription>متابعة المنتجات والكميات المتوفرة</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {inventory.map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <Package className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{item.name}</h3>
                        <p className="text-sm text-gray-600">رمز المنتج: {item.sku}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-600">الكمية</p>
                        <p className="font-bold text-lg">{item.quantity}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600">السعر</p>
                        <p className="font-semibold">{item.price}</p>
                      </div>
                      <Badge className={getStatusColor(item.status)}>{item.status}</Badge>
                      <Button variant="outline" size="sm">
                        تعديل
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="orders" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>إدارة الطلبات</CardTitle>
              <CardDescription>متابعة طلبات العملاء وحالتها</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {orders.map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                        <ShoppingCart className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">طلب رقم: {order.id}</h3>
                        <p className="text-sm text-gray-600">{order.customer}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-600">العناصر</p>
                        <p className="font-bold">{order.items}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600">المجموع</p>
                        <p className="font-semibold">{order.total}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600">التاريخ</p>
                        <p className="text-sm">{order.date}</p>
                      </div>
                      <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
                      <Button variant="outline" size="sm">
                        عرض التفاصيل
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="suppliers" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>إدارة الموردين</CardTitle>
              <CardDescription>متابعة الموردين وتقييمهم</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {suppliers.map((supplier) => (
                  <div key={supplier.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                        <Truck className="w-6 h-6 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{supplier.name}</h3>
                        <p className="text-sm text-gray-600">{supplier.products} منتج</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-600">الطلبات</p>
                        <p className="font-bold">{supplier.orders}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600">التقييم</p>
                        <p className="font-semibold">{supplier.rating}/5</p>
                      </div>
                      <Badge className={getStatusColor(supplier.status)}>{supplier.status}</Badge>
                      <Button variant="outline" size="sm">
                        عرض التفاصيل
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
