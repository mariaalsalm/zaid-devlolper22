"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  BarChart3,
  Users,
  DollarSign,
  Calendar,
  Clock,
  Target,
  CheckCircle,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react"

export default function DashboardOverview() {
  const stats = [
    {
      title: "إجمالي الإيرادات",
      value: "2,450,000 ر.س",
      change: "+12.5%",
      trend: "up",
      icon: DollarSign,
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
    {
      title: "العملاء النشطون",
      value: "1,234",
      change: "+8.2%",
      trend: "up",
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
    },
    {
      title: "المشاريع الجارية",
      value: "45",
      change: "-2.1%",
      trend: "down",
      icon: Target,
      color: "text-orange-600",
      bgColor: "bg-orange-100",
    },
    {
      title: "معدل الإنجاز",
      value: "94.2%",
      change: "+5.3%",
      trend: "up",
      icon: CheckCircle,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
    },
  ]

  const recentActivities = [
    { id: 1, action: "تم إنشاء فاتورة جديدة", user: "أحمد محمد", time: "منذ 5 دقائق", type: "invoice" },
    { id: 2, action: "تم إضافة عميل جديد", user: "فاطمة علي", time: "منذ 15 دقيقة", type: "customer" },
    { id: 3, action: "تم تحديث مشروع", user: "محمد سالم", time: "منذ 30 دقيقة", type: "project" },
    { id: 4, action: "تم إنجاز مهمة", user: "سارة أحمد", time: "منذ ساعة", type: "task" },
  ]

  const upcomingTasks = [
    { id: 1, title: "مراجعة التقارير الشهرية", dueDate: "اليوم", priority: "high" },
    { id: 2, title: "اجتماع مع العميل الجديد", dueDate: "غداً", priority: "medium" },
    { id: 3, title: "تحديث قاعدة البيانات", dueDate: "خلال 3 أيام", priority: "low" },
    { id: 4, title: "إعداد العرض التقديمي", dueDate: "خلال أسبوع", priority: "medium" },
  ]

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">لوحة التحكم الرئيسية</h1>
          <p className="text-gray-600 mt-1">نظرة عامة على أداء الأعمال</p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="outline" className="gap-2">
            <Activity className="w-4 h-4" />
            آخر تحديث: الآن
          </Badge>
          <Button size="sm" className="gap-2">
            <BarChart3 className="w-4 h-4" />
            تقرير مفصل
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
                    <div className="flex items-center mt-2">
                      {stat.trend === "up" ? (
                        <ArrowUpRight className="w-4 h-4 text-green-600" />
                      ) : (
                        <ArrowDownRight className="w-4 h-4 text-red-600" />
                      )}
                      <span
                        className={`text-sm font-medium ${stat.trend === "up" ? "text-green-600" : "text-red-600"}`}
                      >
                        {stat.change}
                      </span>
                      <span className="text-sm text-gray-500 mr-2">من الشهر الماضي</span>
                    </div>
                  </div>
                  <div className={`p-3 rounded-full ${stat.bgColor}`}>
                    <Icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activities */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              الأنشطة الأخيرة
            </CardTitle>
            <CardDescription>آخر العمليات في النظام</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-center gap-4 p-3 rounded-lg bg-gray-50">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{activity.action}</p>
                    <p className="text-sm text-gray-600">بواسطة {activity.user}</p>
                  </div>
                  <span className="text-xs text-gray-500">{activity.time}</span>
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full mt-4 bg-transparent">
              عرض جميع الأنشطة
            </Button>
          </CardContent>
        </Card>

        {/* Upcoming Tasks */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              المهام القادمة
            </CardTitle>
            <CardDescription>المهام المطلوب إنجازها قريباً</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingTasks.map((task) => (
                <div key={task.id} className="flex items-center gap-4 p-3 rounded-lg border">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{task.title}</p>
                    <p className="text-sm text-gray-600">موعد الإنجاز: {task.dueDate}</p>
                  </div>
                  <Badge
                    variant={
                      task.priority === "high" ? "destructive" : task.priority === "medium" ? "default" : "secondary"
                    }
                  >
                    {task.priority === "high" ? "عالية" : task.priority === "medium" ? "متوسطة" : "منخفضة"}
                  </Badge>
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full mt-4 bg-transparent">
              عرض جميع المهام
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>الإجراءات السريعة</CardTitle>
          <CardDescription>الوظائف الأكثر استخداماً</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button variant="outline" className="h-20 flex-col gap-2 bg-transparent">
              <DollarSign className="w-6 h-6" />
              فاتورة جديدة
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2 bg-transparent">
              <Users className="w-6 h-6" />
              إضافة عميل
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2 bg-transparent">
              <Target className="w-6 h-6" />
              مشروع جديد
            </Button>
            <Button variant="outline" className="h-20 flex-col gap-2 bg-transparent">
              <BarChart3 className="w-6 h-6" />
              تقرير سريع
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
