"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Shield, Users, Monitor, AlertTriangle, Eye, Settings, Activity } from "lucide-react"

export default function AdvancedSecuritySystem() {
  const securityScore = 92

  const securityMetrics = [
    { label: "المستخدمون المحميون", value: "156/156", percentage: 100, color: "text-green-600" },
    { label: "الأجهزة المصرح بها", value: "89/95", percentage: 94, color: "text-blue-600" },
    { label: "التهديدات المحجوبة", value: "1,234", percentage: 98, color: "text-purple-600" },
    { label: "معدل الامتثال", value: "98.5%", percentage: 98, color: "text-orange-600" },
  ]

  const securityEvents = [
    {
      id: 1,
      type: "تسجيل دخول مشبوه",
      user: "أحمد محمد",
      location: "الرياض، السعودية",
      time: "منذ 5 دقائق",
      severity: "متوسط",
      status: "تم الحجب",
    },
    {
      id: 2,
      type: "محاولة وصول غير مصرح",
      user: "غير معروف",
      location: "عنوان IP مجهول",
      time: "منذ 15 دقيقة",
      severity: "عالي",
      status: "تم الحجب",
    },
    {
      id: 3,
      type: "تغيير كلمة مرور",
      user: "فاطمة علي",
      location: "جدة، السعودية",
      time: "منذ 30 دقيقة",
      severity: "منخفض",
      status: "مكتمل",
    },
  ]

  const userPermissions = [
    {
      id: 1,
      name: "أحمد محمد السالم",
      role: "مدير النظام",
      permissions: ["قراءة", "كتابة", "حذف", "إدارة"],
      lastLogin: "2024-01-16 09:30",
      status: "نشط",
    },
    {
      id: 2,
      name: "فاطمة علي أحمد",
      role: "مديرة المبيعات",
      permissions: ["قراءة", "كتابة"],
      lastLogin: "2024-01-16 08:45",
      status: "نشط",
    },
    {
      id: 3,
      name: "محمد سالم الأحمد",
      role: "محاسب",
      permissions: ["قراءة", "كتابة"],
      lastLogin: "2024-01-15 17:20",
      status: "غير نشط",
    },
  ]

  const deviceSecurity = [
    {
      id: 1,
      device: "iPhone 15 Pro",
      user: "أحمد محمد",
      location: "الرياض",
      lastAccess: "منذ 5 دقائق",
      status: "موثوق",
      riskLevel: "منخفض",
    },
    {
      id: 2,
      device: "MacBook Pro",
      user: "فاطمة علي",
      location: "جدة",
      lastAccess: "منذ 15 دقيقة",
      status: "موثوق",
      riskLevel: "منخفض",
    },
    {
      id: 3,
      device: "Windows PC",
      user: "محمد سالم",
      location: "الدمام",
      lastAccess: "منذ ساعة",
      status: "مشبوه",
      riskLevel: "متوسط",
    },
  ]

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "عالي":
        return "bg-red-100 text-red-800"
      case "متوسط":
        return "bg-yellow-100 text-yellow-800"
      case "منخفض":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "نشط":
      case "موثوق":
      case "مكتمل":
        return "bg-green-100 text-green-800"
      case "غير نشط":
      case "معلق":
        return "bg-yellow-100 text-yellow-800"
      case "مشبوه":
      case "تم الحجب":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "عالي":
        return "text-red-600"
      case "متوسط":
        return "text-yellow-600"
      case "منخفض":
        return "text-green-600"
      default:
        return "text-gray-600"
    }
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">نظام الأمان المتقدم</h1>
          <p className="text-gray-600 mt-1">مراقبة وإدارة أمان النظام والمستخدمين</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2 bg-transparent">
            <Settings className="w-4 h-4" />
            إعدادات الأمان
          </Button>
          <Button className="gap-2">
            <Shield className="w-4 h-4" />
            تقرير أمني
          </Button>
        </div>
      </div>

      {/* Security Score */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">نقاط الأمان الإجمالية</h2>
              <p className="text-gray-600">تقييم شامل لمستوى أمان النظام</p>
            </div>
            <div className="text-center">
              <div className="relative w-24 h-24">
                <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    stroke="currentColor"
                    strokeWidth="8"
                    fill="transparent"
                    className="text-gray-200"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    stroke="currentColor"
                    strokeWidth="8"
                    fill="transparent"
                    strokeDasharray={`${2 * Math.PI * 40}`}
                    strokeDashoffset={`${2 * Math.PI * 40 * (1 - securityScore / 100)}`}
                    className="text-green-600"
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-2xl font-bold text-green-600">{securityScore}</span>
                </div>
              </div>
              <p className="text-sm text-gray-600 mt-2">ممتاز</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {securityMetrics.map((metric, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">{metric.value}</p>
                <p className="text-sm text-gray-600 mt-1">{metric.label}</p>
                <div className="mt-3">
                  <Progress value={metric.percentage} className="h-2" />
                  <p className={`text-sm font-medium mt-2 ${metric.color}`}>{metric.percentage}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content */}
      <Tabs defaultValue="events" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="events">الأحداث الأمنية</TabsTrigger>
          <TabsTrigger value="users">إدارة المستخدمين</TabsTrigger>
          <TabsTrigger value="devices">الأجهزة</TabsTrigger>
          <TabsTrigger value="reports">التقارير</TabsTrigger>
        </TabsList>

        <TabsContent value="events" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" />
                الأحداث الأمنية الأخيرة
              </CardTitle>
              <CardDescription>مراقبة الأنشطة المشبوهة والتهديدات</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {securityEvents.map((event) => (
                  <div key={event.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                        <AlertTriangle className="w-6 h-6 text-red-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{event.type}</h3>
                        <p className="text-sm text-gray-600">المستخدم: {event.user}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          {event.location} • {event.time}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <Badge className={getSeverityColor(event.severity)}>{event.severity}</Badge>
                      <Badge className={getStatusColor(event.status)}>{event.status}</Badge>
                      <Button variant="outline" size="sm">
                        تفاصيل
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                إدارة صلاحيات المستخدمين
              </CardTitle>
              <CardDescription>مراقبة وإدارة صلاحيات الوصول</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {userPermissions.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <Users className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{user.name}</h3>
                        <p className="text-sm text-gray-600">{user.role}</p>
                        <p className="text-xs text-gray-500 mt-1">آخر دخول: {user.lastLogin}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <p className="text-sm text-gray-600">الصلاحيات</p>
                        <div className="flex gap-1 mt-1">
                          {user.permissions.map((permission, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {permission}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <Badge className={getStatusColor(user.status)}>{user.status}</Badge>
                      <Button variant="outline" size="sm">
                        تعديل
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="devices" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Monitor className="w-5 h-5" />
                إدارة الأجهزة
              </CardTitle>
              <CardDescription>مراقبة الأجهزة المتصلة وتقييم المخاطر</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {deviceSecurity.map((device) => (
                  <div key={device.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                        <Monitor className="w-6 h-6 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{device.device}</h3>
                        <p className="text-sm text-gray-600">المستخدم: {device.user}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          {device.location} • {device.lastAccess}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <p className="text-sm text-gray-600">مستوى المخاطر</p>
                        <p className={`font-semibold ${getRiskColor(device.riskLevel)}`}>{device.riskLevel}</p>
                      </div>
                      <Badge className={getStatusColor(device.status)}>{device.status}</Badge>
                      <Button variant="outline" size="sm">
                        إدارة
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5" />
                  إحصائيات الأمان
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">محاولات الدخول الناجحة</span>
                  <span className="font-semibold text-green-600">1,234</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">محاولات الدخول الفاشلة</span>
                  <span className="font-semibold text-red-600">45</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">التهديدات المحجوبة</span>
                  <span className="font-semibold text-orange-600">89</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">الجلسات النشطة</span>
                  <span className="font-semibold text-blue-600">156</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="w-5 h-5" />
                  تقارير الامتثال
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">معيار ISO 27001</span>
                  <Badge className="bg-green-100 text-green-800">متوافق</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">GDPR</span>
                  <Badge className="bg-green-100 text-green-800">متوافق</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">SOC 2</span>
                  <Badge className="bg-yellow-100 text-yellow-800">قيد المراجعة</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">PCI DSS</span>
                  <Badge className="bg-green-100 text-green-800">متوافق</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
